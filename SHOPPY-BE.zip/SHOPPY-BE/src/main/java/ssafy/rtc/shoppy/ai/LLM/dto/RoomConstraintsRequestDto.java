package ssafy.rtc.shoppy.ai.llm.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record RoomConstraintsRequestDto(
        @NotBlank
        String purpose,

        @NotNull
        @Min(1)
        Integer peopleCount,

        @NotEmpty
        List<String> interestCategories,

        @NotNull
        List<String> traits
) {
}
